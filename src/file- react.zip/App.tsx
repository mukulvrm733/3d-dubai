import { useEffect, useRef, useState } from 'react'
import './App.css'

/* ─────────────────── DATA ─────────────────── */
const tickerItems = [
  { label: 'Dubai Avg ROI', val: '+10.2%' },
  { label: 'AED/USD Peg', val: 'Stable Since 1997' },
  { label: 'Income Tax', val: '0%' },
  { label: 'Golden Visa', val: '$550K+' },
  { label: 'Downtown Yield', val: '8.4%' },
  { label: 'Palm Jumeirah Yield', val: '7.8%' },
  { label: 'Business Bay Yield', val: '10.4%' },
  { label: 'Foreign Ownership', val: '100%' },
]

const properties = [
  {
    badge: 'Penthouse',
    img: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=700&q=80',
    price: '$3,200,000',
    name: 'Burj Khalifa Residences',
    loc: '📍 Downtown Dubai',
    beds: '4', baths: '3', sqft: '4,800',
    backPrice: '$3.2M',
    rows: [
      { k: 'Annual Yield', v: '8.4%' },
      { k: 'Monthly Rent Est.', v: '$22,400' },
      { k: 'Service Charge', v: '$18/sqft/yr' },
      { k: 'Status', v: 'Ready Now' },
      { k: 'Golden Visa', v: '✓ Eligible' },
    ],
  },
  {
    badge: 'Signature Villa',
    img: 'https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?w=700&q=80',
    price: '$5,800,000',
    name: 'Palm Frond Villa',
    loc: '📍 Palm Jumeirah',
    beds: '6', baths: '7', sqft: '8,200',
    backPrice: '$5.8M',
    rows: [
      { k: 'Annual Yield', v: '7.8%' },
      { k: 'Monthly Rent Est.', v: '$37,700' },
      { k: 'Service Charge', v: '$22/sqft/yr' },
      { k: 'Status', v: 'Ready Now' },
      { k: 'Golden Visa', v: '✓ Eligible' },
    ],
  },
  {
    badge: 'Off-Plan',
    img: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=700&q=80',
    price: '$890,000',
    name: 'Creek Harbour Residences',
    loc: '📍 Dubai Creek Harbour',
    beds: '2', baths: '2', sqft: '1,450',
    backPrice: '$890K',
    rows: [
      { k: 'Annual Yield', v: '9.2%' },
      { k: 'Monthly Rent Est.', v: '$6,820' },
      { k: 'Payment Plan', v: '60/40 Split' },
      { k: 'Completion', v: 'Q3 2026' },
      { k: 'Golden Visa', v: '✓ Eligible' },
    ],
  },
  {
    badge: 'Luxury Apt',
    img: 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=700&q=80',
    price: '$1,650,000',
    name: 'Marina Gate Tower',
    loc: '📍 Dubai Marina',
    beds: '3', baths: '3', sqft: '2,100',
    backPrice: '$1.65M',
    rows: [
      { k: 'Annual Yield', v: '8.9%' },
      { k: 'Monthly Rent Est.', v: '$12,240' },
      { k: 'Service Charge', v: '$15/sqft/yr' },
      { k: 'Status', v: 'Ready Now' },
      { k: 'Golden Visa', v: '✓ Eligible' },
    ],
  },
  {
    badge: 'Best Value',
    img: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?w=700&q=80',
    price: '$480,000',
    name: 'Business Bay Studio+',
    loc: '📍 Business Bay',
    beds: '1', baths: '1', sqft: '780',
    backPrice: '$480K',
    rows: [
      { k: 'Annual Yield', v: '10.4%' },
      { k: 'Monthly Rent Est.', v: '$4,160' },
      { k: 'Payment Plan', v: '50/50 Split' },
      { k: 'Completion', v: 'Q1 2026' },
      { k: 'Golden Visa', v: '✓ Eligible' },
    ],
  },
  {
    badge: 'Ultra Luxury',
    img: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=700&q=80',
    price: '$12,500,000',
    name: 'DIFC Skyline Mansion',
    loc: '📍 DIFC',
    beds: '7', baths: '8', sqft: '14,000',
    backPrice: '$12.5M',
    rows: [
      { k: 'Annual Yield', v: '7.2%' },
      { k: 'Monthly Rent Est.', v: '$75,000' },
      { k: 'Service Charge', v: '$28/sqft/yr' },
      { k: 'Status', v: 'Ready Now' },
      { k: 'Golden Visa', v: '✓ Eligible' },
    ],
  },
]

const neighborhoods = [
  { area: 'Downtown Dubai', name: 'Burj Khalifa\nDistrict', from: 'From $800,000', detail: 'Highest prestige address. 7–9% yield. Burj Khalifa views, world-class amenities. Strongest rental demand in Dubai.', img: 'https://images.unsplash.com/photo-1519684378050-8a5ced8e3552?w=700&q=80' },
  { area: 'Palm Jumeirah', name: 'The World-Famous\nPalm Island', from: 'From $1,200,000', detail: 'Iconic. Private beach access. 7–8% yield. Ultra-luxury status. Short-term rentals earn $500–$2,000/night.', img: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=700&q=80' },
  { area: 'Dubai Marina', name: 'Waterfront\nLiving', from: 'From $450,000', detail: 'Highest occupancy rates. 8–10% yield. Year-round tourist and expat demand. Walk-to-everything lifestyle.', img: 'https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?w=700&q=80' },
  { area: 'Business Bay', name: "Dubai's\nManhattan", from: 'From $480,000', detail: 'Corporate hub. 9–11% yield. Corporate tenant demand ensures near 100% occupancy all year.', img: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=700&q=80' },
  { area: 'Dubai Creek Harbour', name: 'The Next\nDowntown', from: 'From $350,000', detail: "Future home of world's tallest tower. 10–12% yield. Maximum appreciation potential. Buy before completion.", img: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=700&q=80' },
]

const roiData = [
  { city: 'Dubai', val: '10.2%', w: 0.81 },
  { city: 'Miami', val: '5.1%', w: 0.41 },
  { city: 'New York', val: '3.9%', w: 0.31 },
  { city: 'Los Angeles', val: '3.2%', w: 0.26 },
]

const mapDots = [
  { x: '28%', y: '38%', label: 'Downtown' },
  { x: '18%', y: '62%', label: 'Marina' },
  { x: '42%', y: '55%', label: 'Business Bay' },
  { x: '14%', y: '44%', label: 'JBR' },
  { x: '60%', y: '42%', label: 'Creek' },
]

const stats = [
  { cnt: 2400, pfx: '', sfx: '+', label: 'American Clients' },
  { cnt: 1200, pfx: '$', sfx: 'M+', label: 'Portfolio Value' },
  { cnt: 10, pfx: '', sfx: '%', label: 'Avg Annual ROI' },
  { cnt: 97, pfx: '', sfx: '%', label: 'Client Satisfaction' },
]

const processSteps = [
  { num: '01', t: 'Free Strategy Call', d: '30-minute video call with a US-based Dubai specialist. We map your goals, budget, and risk profile — no jargon, just clarity.' },
  { num: '02', t: 'Curated Property Shortlist', d: 'Receive 3–5 properties matching your criteria, each with a full financial model, 360° tour, and legal due diligence report.' },
  { num: '03', t: 'Remote Purchase & Legal', d: 'Sign digitally. Wire via SWIFT. We handle DLD registration, title deed, and all UAE legal requirements from our Dubai office.' },
  { num: '04', t: 'Earn Monthly — We Manage All', d: 'Full property management. Tenant sourcing, maintenance, legal compliance. Monthly USD wire directly to your US bank account.' },
]

const procItems = [
  { ico: '🔍', txt: 'Property sourcing & due diligence' },
  { ico: '⚖️', txt: 'UAE legal & DLD registration' },
  { ico: '🧾', txt: 'RERA compliance & contracts' },
  { ico: '👥', txt: 'Tenant screening & placement' },
  { ico: '🔧', txt: 'Ongoing maintenance & repairs' },
  { ico: '💸', txt: 'Monthly USD wire to your account' },
  { ico: '📊', txt: 'Quarterly performance reports' },
  { ico: '🛂', txt: 'Golden Visa application support' },
]

const testimonials = [
  {
    featured: true,
    stars: '★★★★★',
    text: '"I was skeptical about investing overseas. But Aurum made it completely seamless. My Marina apartment earns 9.4% annually — far more than anything in New York. The monthly wire transfers are like clockwork. I\'ve since bought two more units."',
    av: 'JM', name: 'James Mitchell', from: 'Portfolio Manager · San Francisco, CA',
  },
  {
    featured: false,
    stars: '★★★★★',
    text: '"We purchased two off-plan units in Dubai Creek Harbour. They appreciated 34% before completion. Aurum handled everything remotely — we\'ve never visited Dubai."',
    av: 'SR', name: 'Sarah & Robert Chen', from: 'Entrepreneurs · Austin, TX',
  },
  {
    featured: false,
    stars: '★★★★★',
    text: '"The Golden Visa for my family was worth the investment alone. And the 10.4% ROI on my Business Bay unit? My NYC condo barely does 3%."',
    av: 'DW', name: 'David Weiss', from: 'Real Estate Attorney · Miami, FL',
  },
  {
    featured: false,
    stars: '★★★★★',
    text: '"My Palm Jumeirah villa earns $38K/month. Net over $400K annually — tax free. This was the best financial decision I\'ve ever made."',
    av: 'AL', name: 'Amanda Liu', from: 'Tech Executive · Seattle, WA',
  },
]

/* ─────────────────── RIPPLE HELPER ─────────────────── */
function addRipple(e: React.MouseEvent<HTMLElement>) {
  const btn = e.currentTarget
  const r = document.createElement('span')
  r.className = 'ripple'
  const rect = btn.getBoundingClientRect()
  const size = Math.max(rect.width, rect.height)
  r.style.cssText = `width:${size}px;height:${size}px;left:${e.clientX - rect.left - size / 2}px;top:${e.clientY - rect.top - size / 2}px`
  btn.appendChild(r)
  setTimeout(() => r.remove(), 700)
}

function scrollTo(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
}

/* ─────────────────── APP ─────────────────── */
export default function App() {
  const [preloaderGone, setPreloaderGone] = useState(false)
  const [navSolid, setNavSolid] = useState(false)
  const [hsIdx, setHsIdx] = useState(0)
  const [formDone, setFormDone] = useState(false)
  const [roiAnimated, setRoiAnimated] = useState(false)
  const [procLineIn, setProcLineIn] = useState(false)
  const [counters, setCounters] = useState(stats.map(() => 0))
  const [activeDot, setActiveDot] = useState('hero')

  const curRef = useRef<HTMLDivElement>(null)
  const cur2Ref = useRef<HTMLDivElement>(null)
  const heroBgRef = useRef<HTMLDivElement>(null)
  const g1Ref = useRef<HTMLDivElement>(null)
  const g2Ref = useRef<HTMLDivElement>(null)
  const roiBarsRef = useRef<HTMLDivElement>(null)
  const procStepsRef = useRef<HTMLDivElement>(null)
  const hsTrackRef = useRef<HTMLDivElement>(null)
  const hsCardRef = useRef<HTMLDivElement>(null)
  const cardStackRef = useRef<HTMLDivElement>(null)
  const tourVisRef = useRef<HTMLDivElement>(null)
  const tourCardRef = useRef<HTMLDivElement>(null)
  const progressRef = useRef<HTMLDivElement>(null)

  /* Preloader */
  useEffect(() => {
    const t = setTimeout(() => setPreloaderGone(true), 2400)
    return () => clearTimeout(t)
  }, [])

  /* Scroll events */
  useEffect(() => {
    let scrollY = 0
    let mouseX = 0, mouseY = 0

    const onScroll = () => {
      scrollY = window.scrollY
      setNavSolid(scrollY > 60)
      // scroll progress
      const pct = scrollY / (document.documentElement.scrollHeight - window.innerHeight) * 100
      if (progressRef.current) progressRef.current.style.width = pct + '%'
      // parallax
      if (heroBgRef.current) heroBgRef.current.style.transform = `translateY(${scrollY * 0.4}px) translateZ(0)`
      if (g1Ref.current) g1Ref.current.style.transform = `translateY(${scrollY * 0.22}px) translate(${mouseX * 0.5}px,${mouseY * 0.4}px)`
      if (g2Ref.current) g2Ref.current.style.transform = `translateY(${scrollY * -0.13}px) translate(${mouseX * -0.35}px,${mouseY * -0.3}px)`
    }
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  /* Cursor */
  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      if (curRef.current) { curRef.current.style.left = e.clientX + 'px'; curRef.current.style.top = e.clientY + 'px' }
      if (cur2Ref.current) { cur2Ref.current.style.left = e.clientX + 'px'; cur2Ref.current.style.top = e.clientY + 'px' }
    }
    document.addEventListener('mousemove', onMove)
    return () => document.removeEventListener('mousemove', onMove)
  }, [])

  /* Scroll reveal */
  useEffect(() => {
    const io = new IntersectionObserver(entries => {
      entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('up') })
    }, { threshold: 0.1 })
    document.querySelectorAll('.sr,.srl,.srr').forEach(el => io.observe(el))
    return () => io.disconnect()
  }, [])

  /* ROI bars */
  useEffect(() => {
    if (!roiBarsRef.current) return
    const io = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) { setRoiAnimated(true); io.disconnect() }
    }, { threshold: 0.4 })
    io.observe(roiBarsRef.current)
    return () => io.disconnect()
  }, [])

  /* Process line */
  useEffect(() => {
    if (!procStepsRef.current) return
    const io = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) { setProcLineIn(true); io.disconnect() }
    }, { threshold: 0.15 })
    io.observe(procStepsRef.current)
    return () => io.disconnect()
  }, [])

  /* Counters */
  useEffect(() => {
    const els = document.querySelectorAll('.stat-n[data-cnt]')
    const io = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (!e.isIntersecting) return
        const el = e.target as HTMLElement
        const target = +(el.dataset.cnt || 0)
        const pfx = el.dataset.pfx || ''
        const sfx = el.dataset.sfx || ''
        let cur = 0
        const inc = target / 60
        const t = setInterval(() => {
          cur = Math.min(cur + inc, target)
          el.textContent = pfx + Math.floor(cur).toLocaleString() + sfx
          if (cur >= target) clearInterval(t)
        }, 25)
        io.unobserve(el)
      })
    }, { threshold: 0.5 })
    els.forEach(el => io.observe(el))
    return () => io.disconnect()
  }, [])

  /* Section dot nav */
  useEffect(() => {
    const sections = ['hero', 'why', 'properties', 'areas', 'tour', 'process', 'testimonials', 'contact']
    const io = new IntersectionObserver(entries => {
      entries.forEach(e => { if (e.isIntersecting) setActiveDot(e.target.id) })
    }, { threshold: 0.35 })
    sections.forEach(id => { const el = document.getElementById(id); if (el) io.observe(el) })
    return () => io.disconnect()
  }, [])

  /* Stagger contact items */
  useEffect(() => {
    const items = [...document.querySelectorAll('.ci-item,.ts-row,.pc-item')] as HTMLElement[]
    items.forEach((el, i) => {
      el.style.opacity = '0'
      el.style.transform = 'translateX(-16px)'
      el.style.transition = `opacity .5s ease ${i * 0.08}s,transform .5s ease ${i * 0.08}s`
      const io = new IntersectionObserver(en => {
        if (en[0].isIntersecting) { el.style.opacity = '1'; el.style.transform = ''; io.disconnect() }
      }, { threshold: 0.2 })
      io.observe(el)
    })
  }, [])

  /* 3D tilt - bento & testimonials */
  useEffect(() => {
    const cards = [...document.querySelectorAll('.b,.tc')] as HTMLElement[]
    const mousemove = (e: MouseEvent) => {
      const card = e.currentTarget as HTMLElement
      const r = card.getBoundingClientRect()
      const x = (e.clientX - r.left) / r.width - 0.5
      const y = (e.clientY - r.top) / r.height - 0.5
      card.style.transform = `perspective(900px) rotateX(${-y * 7}deg) rotateY(${x * 7}deg) translateY(-4px)`
      card.style.transition = 'transform .08s linear'
    }
    const mouseleave = (e: MouseEvent) => {
      const card = e.currentTarget as HTMLElement
      card.style.transform = ''
      card.style.transition = 'transform .5s cubic-bezier(.4,0,.2,1),border-color .4s ease'
    }
    cards.forEach(c => { c.addEventListener('mousemove', mousemove); c.addEventListener('mouseleave', mouseleave) })
    return () => cards.forEach(c => { c.removeEventListener('mousemove', mousemove); c.removeEventListener('mouseleave', mouseleave) })
  }, [])

  /* Tour card tilt */
  useEffect(() => {
    const vis = tourVisRef.current
    const card = tourCardRef.current
    if (!vis || !card) return
    const mm = (e: MouseEvent) => {
      const r = vis.getBoundingClientRect()
      const x = (e.clientX - r.left) / r.width - 0.5
      const y = (e.clientY - r.top) / r.height - 0.5
      card.style.animation = 'none'
      card.style.transform = `rotateY(${x * 12}deg) rotateX(${-y * 8}deg)`
    }
    const ml = () => { card.style.transform = ''; setTimeout(() => { card.style.animation = '' }, 50) }
    vis.addEventListener('mousemove', mm)
    vis.addEventListener('mouseleave', ml)
    return () => { vis.removeEventListener('mousemove', mm); vis.removeEventListener('mouseleave', ml) }
  }, [])

  /* Card stack tilt */
  useEffect(() => {
    const stack = cardStackRef.current
    if (!stack) return
    const mm = (e: MouseEvent) => {
      const rect = stack.getBoundingClientRect()
      const x = ((e.clientX - rect.left) / rect.width - 0.5) * 10
      const y = ((e.clientY - rect.top) / rect.height - 0.5) * -10
      const c0 = stack.querySelector('.c0') as HTMLElement
      if (c0) c0.style.transform = `rotateY(${x}deg) rotateX(${y}deg) translateZ(20px)`
    }
    const ml = () => {
      const c0 = stack.querySelector('.c0') as HTMLElement
      if (c0) c0.style.transform = ''
    }
    stack.addEventListener('mousemove', mm)
    stack.addEventListener('mouseleave', ml)
    return () => { stack.removeEventListener('mousemove', mm); stack.removeEventListener('mouseleave', ml) }
  }, [])

  /* Hover cursor */
  useEffect(() => {
    const hoverEls = document.querySelectorAll('a,button,.fc,.nh,.b,.tc,.proc-step,.ci-item,.tf,.fs,.fcta')
    const add = () => document.body.classList.add('hovering')
    const remove = () => document.body.classList.remove('hovering')
    hoverEls.forEach(el => { el.addEventListener('mouseenter', add); el.addEventListener('mouseleave', remove) })
    return () => hoverEls.forEach(el => { el.removeEventListener('mouseenter', add); el.removeEventListener('mouseleave', remove) })
  }, [])

  /* Magnetic buttons */
  useEffect(() => {
    const btns = [...document.querySelectorAll('.btn-gold,.n-cta')] as HTMLElement[]
    const mm = (e: MouseEvent) => {
      const btn = e.currentTarget as HTMLElement
      const r = btn.getBoundingClientRect()
      const x = (e.clientX - r.left - r.width / 2) * 0.3
      const y = (e.clientY - r.top - r.height / 2) * 0.3
      btn.style.transform = `translate(${x}px,${y - 2}px)`
    }
    const ml = (e: MouseEvent) => { (e.currentTarget as HTMLElement).style.transform = '' }
    btns.forEach(b => { b.addEventListener('mousemove', mm); b.addEventListener('mouseleave', ml) })
    return () => btns.forEach(b => { b.removeEventListener('mousemove', mm); b.removeEventListener('mouseleave', ml) })
  }, [])

  /* HS move */
  function hsMove(d: number) {
    const card = hsCardRef.current
    if (!card) return
    const visible = window.innerWidth < 768 ? 1 : window.innerWidth < 1100 ? 2 : 3
    const max = Math.max(0, neighborhoods.length - visible)
    const next = Math.max(0, Math.min(max, hsIdx + d))
    setHsIdx(next)
    const w = card.offsetWidth + 20 // gap
    if (hsTrackRef.current) hsTrackRef.current.style.transform = `translateX(-${next * w}px)`
  }

  const sections = ['hero', 'why', 'properties', 'areas', 'tour', 'process', 'testimonials', 'contact']

  return (
    <>
      {/* Scroll progress */}
      <div id="scroll-progress" ref={progressRef} />

      {/* Cursor */}
      <div id="cur" ref={curRef} />
      <div id="cur2" ref={cur2Ref} />

      {/* Preloader */}
      <div id="pl" className={preloaderGone ? 'gone' : ''}>
        <div className="pl-wordmark">AURUM</div>
        <div className="pl-line" />
        <div className="pl-sub">Dubai Premium Real Estate</div>
      </div>

      {/* Section dot nav */}
      <div className="section-marker">
        {sections.map(id => (
          <div
            key={id}
            className={`sm-dot${activeDot === id ? ' active' : ''}`}
            title={id.charAt(0).toUpperCase() + id.slice(1)}
            onClick={() => scrollTo(id)}
          />
        ))}
      </div>

      {/* NAV */}
      <nav className={navSolid ? 'solid' : ''}>
        <div className="n-logo">
          <div className="n-logo-mark">A</div>
          AURUM
        </div>
        <div className="n-links">
          <a href="#properties">Properties</a>
          <a href="#why">Why Dubai</a>
          <a href="#areas">Areas</a>
          <a href="#tour">Virtual Tour</a>
          <a href="#testimonials">Reviews</a>
          <button className="n-cta" onClick={e => { addRipple(e); scrollTo('contact') }}>Consult Free</button>
        </div>
      </nav>

      {/* ══ HERO ══ */}
      <section id="hero">
        <div className="hero-bg">
          <div className="hero-bg-img" ref={heroBgRef} />
          <div className="hero-bg-overlay" />
          <div className="hero-bg-shimmer" />
        </div>
        <div className="hero-glow g1" ref={g1Ref} />
        <div className="hero-glow g2" ref={g2Ref} />

        <div className="hero-l">
          <div className="hero-eyebrow">
            <span />
            Trusted by 2,400+ American Investors
          </div>
          <h1 className="hero-h1">
            Dubai's Finest<br />
            Real Estate,<br />
            <em>Zero Tax</em>
          </h1>
          <p className="hero-desc">
            Premium Dubai properties delivering 8–12% annual returns — fully managed from the United States. No tax. No complexity. Pure return.
          </p>
          <div className="hero-actions">
            <button className="btn-gold" onClick={e => { addRipple(e); scrollTo('properties') }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z" /></svg>
              Explore Properties
            </button>
            <button className="btn-ghost" onClick={e => { addRipple(e); scrollTo('tour') }}>
              ▶ &nbsp;Virtual Tour
            </button>
          </div>
          <div className="hero-trust">
            <div className="trust-avatars">
              {['JM', 'SR', 'DW', 'AL', '+'].map(av => <div key={av} className="trust-av">{av}</div>)}
            </div>
            <div className="trust-txt">
              <strong>2,400+ Americans invested</strong>
              Average return: 10.2% annually
            </div>
          </div>
        </div>

        {/* Card stack */}
        <div className="hero-r">
          <div className="card-stack" ref={cardStackRef}>
            <div className="stack-card c2">
              <div className="sc-img" style={{ background: "url('https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=600&q=80') center/cover", height: '58%' }} />
              <div className="sc-body">
                <div className="sc-tag">Ultra Luxury</div>
                <div className="sc-price">$12.5M</div>
                <div className="sc-name">DIFC Skyline Mansion</div>
              </div>
            </div>
            <div className="stack-card c1">
              <div className="sc-img" style={{ background: "url('https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?w=600&q=80') center/cover", height: '58%' }} />
              <div className="sc-body">
                <div className="sc-tag">Villa</div>
                <div className="sc-price">$5.8M</div>
                <div className="sc-name">Palm Frond Villa</div>
              </div>
            </div>
            <div className="stack-card c0">
              <div className="sc-img" style={{ background: "url('https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=600&q=80') center/cover", height: '58%' }}>
                <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(0deg,#0E1018 0%,transparent 55%)', zIndex: 1 }} />
              </div>
              <div className="sc-body">
                <div className="sc-tag">Penthouse</div>
                <div className="sc-price">$3,200,000</div>
                <div className="sc-name">Burj Khalifa Residences · Downtown</div>
                <div className="sc-stats">
                  <div className="sc-stat"><strong>8.4%</strong>Annual Yield</div>
                  <div className="sc-stat"><strong>$22.4K</strong>Monthly Rent</div>
                  <div className="sc-stat"><strong>4,800</strong>sq ft</div>
                </div>
              </div>
            </div>
            <div className="float-pill fp1">
              <div className="pill-dot" />
              <span>Live Deal Closed · <span className="pill-num">$2.1M</span> Palm Jumeirah</span>
            </div>
            <div className="float-pill fp2">
              <span>🏆 ROI This Month · <span className="pill-num">+10.8%</span></span>
            </div>
          </div>
        </div>
      </section>

      {/* ══ TICKER ══ */}
      <div className="ticker">
        <div className="ticker-track">
          {[...tickerItems, ...tickerItems].map((item, i) => (
            <div key={i} className="ticker-item">
              {item.label} <span className="ti-val">{item.val}</span>
            </div>
          ))}
        </div>
      </div>

      {/* ══ WHY DUBAI ══ */}
      <section id="why">
        <div className="sh sr">
          <div className="sh-eye">Why Dubai</div>
          <h2 className="sh-h">America's most <em>strategic</em><br />overseas investment</h2>
          <p className="sh-p">Every metric that matters — returns, safety, liquidity, and lifestyle — points to Dubai. Here's the data.</p>
        </div>
        <div className="bento">
          <div className="b b1 sr" data-delay="1">
            <div className="b-label">The destination</div>
            <div className="b-title">Dubai Real Estate<br />Outperforms Every<br />US Metro</div>
            <p className="b-desc" style={{ marginTop: '.5rem' }}>Average yields in Dubai range 7–12%, versus 3–5% in New York or Miami. With zero tax, your net return is unmatched.</p>
            <div className="b-visual">
              <div className="b-visual-bg" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1519684378050-8a5ced8e3552?w=800&q=80')" }} />
            </div>
          </div>
          <div className="b b2 sr" data-delay="2">
            <div className="b-icon">🏦</div>
            <div className="b-num">0%</div>
            <div className="b-label">Income Tax</div>
            <p className="b-desc">Keep every dollar of rental income. No federal, no state, no capital gains tax on property.</p>
          </div>
          <div className="b b3 sr" data-delay="3">
            <div className="b-label">City vs City ROI</div>
            <div className="roi-bars" ref={roiBarsRef}>
              {roiData.map((r, i) => (
                <div key={i} className="roi-row">
                  <div className="roi-meta">{r.city} <span>{r.val}</span></div>
                  <div className="roi-track">
                    <div className={`roi-fill${roiAnimated ? ' anim' : ''}`} style={{ width: `${r.w * 100}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="b b4 sr" data-delay="2">
            <div className="b-icon">🛂</div>
            <div className="b-num" style={{ fontSize: '2.8rem' }}>10-Yr<br />Visa</div>
            <div className="b-label">Golden Visa</div>
            <p className="b-desc">Invest $550K+ and receive UAE residency for your entire family. Renewable every 10 years.</p>
          </div>
          <div className="b b5 sr" data-delay="3">
            <div className="b-icon">💵</div>
            <div className="b-num">27+</div>
            <div className="b-label">Years AED–USD Peg</div>
            <p className="b-desc">Since 1997. Zero currency risk. Your dollar stays a dollar.</p>
          </div>
          <div className="b b6 sr" data-delay="1">
            <div className="b-label">Premium Locations</div>
            <div className="b-title" style={{ fontSize: '1.3rem', marginBottom: '.5rem' }}>5 World-Class<br />Neighborhoods</div>
            <div className="mini-map">
              <div className="map-grid" />
              <div className="map-dots">
                {mapDots.map((dot, i) => (
                  <div key={i} className="map-dot" style={{ left: dot.x, top: dot.y }}>
                    <div className="map-label" style={{ left: '14px', top: '-4px' }}>{dot.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div className="b b7 sr" data-delay="2">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem' }}>
              <div>
                <div className="b-icon">🔒</div>
                <div className="b-title" style={{ fontSize: '1.3rem' }}>#1 Safest City Globally</div>
                <p className="b-desc" style={{ maxWidth: '340px' }}>RERA-regulated, escrow-protected transactions. Dubai law mandates all off-plan funds held in escrow until construction milestones.</p>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '.75rem', minWidth: '180px' }}>
                <div style={{ padding: '1rem', background: 'var(--glass)', border: '1px solid var(--border)', borderRadius: '12px', textAlign: 'center' }}>
                  <div style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: '2rem', color: 'var(--gold)', fontWeight: 600 }}>AAA</div>
                  <div style={{ fontSize: '.68rem', color: 'var(--muted)', letterSpacing: '.12em', textTransform: 'uppercase' }}>Market Rating</div>
                </div>
                <div style={{ padding: '1rem', background: 'var(--glass)', border: '1px solid var(--border)', borderRadius: '12px', textAlign: 'center' }}>
                  <div style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: '2rem', color: 'var(--gold)', fontWeight: 600 }}>100%</div>
                  <div style={{ fontSize: '.68rem', color: 'var(--muted)', letterSpacing: '.12em', textTransform: 'uppercase' }}>Foreign Ownership</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ══ STATS ══ */}
      <div id="stats">
        {stats.map((s, i) => (
          <div key={i} className="stat-block sr" data-delay={String(i)}>
            <div className="stat-n" data-cnt={s.cnt} data-pfx={s.pfx} data-sfx={s.sfx}>{s.pfx}0{s.sfx}</div>
            <div className="stat-l">{s.label}</div>
          </div>
        ))}
      </div>

      {/* ══ PROPERTIES ══ */}
      <section id="properties">
        <div className="sh sr">
          <div className="sh-eye">Featured Listings</div>
          <h2 className="sh-h">Curated for <em>US Investors</em></h2>
          <p className="sh-p">Hover any card to reveal full investment analysis. All prices USD. Financing available via US-based lenders.</p>
        </div>
        <div className="props-grid">
          {properties.map((p, i) => (
            <div key={i} className="fc sr" data-delay={String((i % 3) + 1)}>
              <div className="fc-inner">
                <div className="fc-f">
                  <div className="fc-img">
                    <div className="fc-img-bg" style={{ backgroundImage: `url('${p.img}')` }} />
                    <div className="fc-badge">{p.badge}</div>
                  </div>
                  <div className="fc-info">
                    <div className="fc-price">{p.price}</div>
                    <div className="fc-name">{p.name}</div>
                    <div className="fc-loc">{p.loc}</div>
                    <div className="fc-feats">
                      <div className="fc-feat"><span className="fc-feat-ico">🛏</span>{p.beds} Beds</div>
                      <div className="fc-feat"><span className="fc-feat-ico">🚿</span>{p.baths} Baths</div>
                      <div className="fc-feat"><span className="fc-feat-ico">📐</span>{p.sqft} sqft</div>
                    </div>
                  </div>
                </div>
                <div className="fc-b">
                  <div className="fcb-label">Investment Breakdown</div>
                  <div className="fcb-price">{p.backPrice}</div>
                  <div className="fcb-rows">
                    {p.rows.map((r, j) => (
                      <div key={j} className="fcb-row"><span>{r.k}</span><strong>{r.v}</strong></div>
                    ))}
                  </div>
                  <button className="fcb-btn" onClick={e => { addRipple(e); scrollTo('contact') }}>Book Viewing →</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ══ AREAS ══ */}
      <section id="areas" style={{ padding: '7rem 0 7rem 5%', overflow: 'hidden' }}>
        <div className="areas-header sh sr">
          <div className="sh-eye">Prime Locations</div>
          <h2 className="sh-h">Dubai's Most <em>Coveted</em><br />Neighborhoods</h2>
          <p className="sh-p">Five world-class districts, each with distinct character and investment profile. Hover to reveal details.</p>
        </div>
        <div className="hs-wrap">
          <div className="hs-track" ref={hsTrackRef}>
            {neighborhoods.map((n, i) => (
              <div key={i} className="nh" ref={i === 0 ? hsCardRef : undefined}>
                <div className="nh-bg" style={{ backgroundImage: `url('${n.img}')` }} />
                <div className="nh-ov" />
                <div className="nh-body">
                  <div className="nh-area">{n.area}</div>
                  <div className="nh-name">{n.name.split('\n').map((line, j) => <span key={j}>{line}{j === 0 && <br />}</span>)}</div>
                  <div className="nh-from">{n.from}</div>
                  <div className="nh-detail">{n.detail}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="hs-nav">
          <div className="hs-arr" onClick={e => { addRipple(e as unknown as React.MouseEvent<HTMLElement>); hsMove(-1) }}>←</div>
          <div className="hs-arr" onClick={e => { addRipple(e as unknown as React.MouseEvent<HTMLElement>); hsMove(1) }}>→</div>
        </div>
      </section>

      {/* ══ VIRTUAL TOUR ══ */}
      <section id="tour">
        <div className="tour-wrap">
          <div className="tour-vis srr" ref={tourVisRef}>
            <div className="tour-card" ref={tourCardRef}>
              <div className="tour-bg" />
              <div className="tour-overlay" />
              <div className="tour-play" onClick={() => alert('Integrate Matterport or Kuula 360° embed here.')}>
                <svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z" /></svg>
              </div>
              <div className="tour-label tl1">
                <div className="tl-t">Current Property</div>
                <div className="tl-v">Burj Khalifa Penthouse</div>
              </div>
              <div className="tour-label tl2">
                <div className="tl-t">Live Yield</div>
                <div className="tl-v gold">8.4% p.a.</div>
              </div>
            </div>
          </div>
          <div className="tour-info srl">
            <div className="sh">
              <div className="sh-eye">Immersive Experience</div>
              <h2 className="sh-h">Walk Through<br />Your <em>Future Home</em><br />From New York</h2>
              <p className="sh-p" style={{ marginTop: '1rem' }}>Our 4K 360° virtual tours let you inspect every room, view, and finish before you wire a single dollar.</p>
            </div>
            <div className="tour-feats">
              {[
                { ico: '🎯', t: '4K Resolution · 360°', d: 'Full-sphere tours with dollhouse view, floor plans, and measurement tools built in.' },
                { ico: '🕶️', t: 'VR Headset Compatible', d: 'Stream directly to Oculus Quest, Apple Vision Pro, or any WebXR-compatible headset.' },
                { ico: '👤', t: 'Live Agent Walkthrough', d: 'Book a guided virtual tour with a Dubai agent via video call — available 7 days, EST-friendly hours.' },
              ].map((f, i) => (
                <div key={i} className="tf">
                  <div className="tf-ico">{f.ico}</div>
                  <div>
                    <div className="tf-t">{f.t}</div>
                    <div className="tf-d">{f.d}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ══ PROCESS ══ */}
      <section id="process">
        <div className="sh center sr" style={{ marginBottom: '5rem' }}>
          <div className="sh-eye">How It Works</div>
          <h2 className="sh-h">From <em>America</em> to Dubai<br />in 4 Steps</h2>
          <p className="sh-p">No flights required. Our end-to-end process is built for busy US investors who want results, not red tape.</p>
        </div>
        <div className="proc-grid">
          <div className={`proc-steps${procLineIn ? ' line-in' : ''}`} ref={procStepsRef}>
            {processSteps.map((s, i) => (
              <div key={i} className="proc-step sr" data-delay={String(i + 1)}>
                <div className="ps-num">{s.num}</div>
                <div className="ps-txt">
                  <div className="ps-t">{s.t}</div>
                  <div className="ps-d">{s.d}</div>
                </div>
              </div>
            ))}
          </div>
          <div className="proc-card srr">
            <div className="pc-title">What We Handle For You</div>
            <div className="pc-sub">Everything. You literally just wire funds and receive monthly income.</div>
            <div className="pc-list">
              {procItems.map((item, i) => (
                <div key={i} className="pc-item">
                  <div className="pc-ico">{item.ico}</div>
                  {item.txt}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ══ TESTIMONIALS ══ */}
      <section id="testimonials">
        <div className="sh center sr" style={{ marginBottom: '4rem' }}>
          <div className="sh-eye">Client Stories</div>
          <h2 className="sh-h">What <em>Americans</em><br />Say After Investing</h2>
        </div>
        <div className="testi-grid sr">
          <div className="tc featured">
            <div className="tc-stars">{testimonials[0].stars}</div>
            <p className="tc-text">{testimonials[0].text}</p>
            <div className="tc-author">
              <div className="tc-av">{testimonials[0].av}</div>
              <div>
                <div className="tc-name">{testimonials[0].name}</div>
                <div className="tc-from">{testimonials[0].from}</div>
              </div>
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {testimonials.slice(1).map((t, i) => (
              <div key={i} className="tc">
                <div className="tc-stars">{t.stars}</div>
                <p className="tc-text">{t.text}</p>
                <div className="tc-author">
                  <div className="tc-av">{t.av}</div>
                  <div>
                    <div className="tc-name">{t.name}</div>
                    <div className="tc-from">{t.from}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══ CONTACT ══ */}
      <section id="contact">
        <div className="contact-wrap">
          <div className="contact-info srl">
            <div className="sh">
              <div className="sh-eye">Get Started</div>
              <h2 className="sh-h">Speak with a<br /><em>Dubai Expert</em><br />Today</h2>
              <p className="sh-p" style={{ marginTop: '1rem' }}>Free 30-minute consultation. No commitment. US-based advisors, EST-friendly hours.</p>
            </div>
            <div className="ci-items">
              {[
                { ico: '📞', l: 'US Toll-Free', v: '+1 (800) 555-DUBAI' },
                { ico: '✉️', l: 'Email', v: 'invest@aurumdubai.com' },
                { ico: '🕐', l: 'US Office Hours', v: 'Mon–Sat, 8am–8pm EST' },
                { ico: '🏙️', l: 'New York Office', v: '1540 Broadway, New York, NY 10036' },
              ].map((c, i) => (
                <div key={i} className="ci-item">
                  <div className="ci-ico">{c.ico}</div>
                  <div><div className="ci-l">{c.l}</div><div className="ci-v">{c.v}</div></div>
                </div>
              ))}
            </div>
            <div className="trust-seal">
              <div className="ts-title">Why Trust Aurum</div>
              <div className="ts-list">
                {[
                  'RERA-licensed Dubai brokerage',
                  'US-based legal & compliance team',
                  '$0 advisory fee — ever',
                  '100% escrow-secured transactions',
                  '2,400+ satisfied US investors',
                ].map((item, i) => (
                  <div key={i} className="ts-row"><span className="ts-check">✓</span>{item}</div>
                ))}
              </div>
            </div>
          </div>

          <div className="contact-form srr">
            <div className="cf-title">Book Your Free Call</div>
            <div className="cf-sub">Typically respond within 2 hours during business hours.</div>
            <div className="cf-grid">
              <div className="fg"><label className="fl">First Name</label><input type="text" className="fi" placeholder="John" /></div>
              <div className="fg"><label className="fl">Last Name</label><input type="text" className="fi" placeholder="Smith" /></div>
              <div className="fg"><label className="fl">Email</label><input type="email" className="fi" placeholder="john@example.com" /></div>
              <div className="fg"><label className="fl">Phone</label><input type="tel" className="fi" placeholder="+1 (555) 000-0000" /></div>
              <div className="fg">
                <label className="fl">Investment Budget</label>
                <select className="fi">
                  <option value="">Select range</option>
                  <option>$400K – $800K</option>
                  <option>$800K – $2M</option>
                  <option>$2M – $5M</option>
                  <option>$5M+</option>
                </select>
              </div>
              <div className="fg">
                <label className="fl">Preferred Area</label>
                <select className="fi">
                  <option value="">Any / Suggest One</option>
                  <option>Downtown Dubai</option>
                  <option>Palm Jumeirah</option>
                  <option>Dubai Marina</option>
                  <option>Business Bay</option>
                  <option>Dubai Creek Harbour</option>
                </select>
              </div>
              <div className="fg full">
                <label className="fl">Investment Goals (optional)</label>
                <textarea className="fi" placeholder="e.g. Passive income, Golden Visa, portfolio diversification..." />
              </div>
            </div>
            <button
              className="cf-submit"
              id="cfSubmit"
              style={formDone ? { background: 'linear-gradient(135deg,#2a7a4f,#3daa6e)', boxShadow: '0 8px 32px rgba(74,222,128,.3)' } : {}}
              onClick={e => { addRipple(e); setFormDone(true) }}
              disabled={formDone}
            >
              {formDone ? "✓ Booked! We'll call within 2 hours." : 'Book Free Consultation →'}
            </button>
            <div className="cf-note">We never share your data. Privacy policy applies.</div>
          </div>
        </div>
      </section>

      {/* ══ FOOTER ══ */}
      <footer>
        <div className="ft-grid">
          <div className="ft-brand">
            <div className="ft-logo">AURUM</div>
            <div style={{ fontSize: '.65rem', letterSpacing: '.25em', textTransform: 'uppercase', color: 'var(--gold3)' }}>Dubai Premium Real Estate</div>
            <p className="ft-tagline">America's most trusted gateway to Dubai real estate. Tax-free returns, Golden Visas, world-class lifestyle — managed from home.</p>
            <div className="ft-socials">
              {['in', 'li', '▶', '𝕏'].map((s, i) => <div key={i} className="fs">{s}</div>)}
            </div>
          </div>
          <div className="ft-col">
            <h5>Properties</h5>
            <div className="ft-links">
              {['Apartments', 'Villas', 'Penthouses', 'Off-Plan', 'Commercial'].map(l => <a key={l} href="#">{l}</a>)}
            </div>
          </div>
          <div className="ft-col">
            <h5>Areas</h5>
            <div className="ft-links">
              {['Downtown Dubai', 'Palm Jumeirah', 'Dubai Marina', 'Business Bay', 'DIFC'].map(l => <a key={l} href="#">{l}</a>)}
            </div>
          </div>
          <div className="ft-col">
            <h5>Resources</h5>
            <div className="ft-links">
              {["US Buyer's Guide", 'Golden Visa Info', 'ROI Calculator', 'Market Reports', 'FAQ'].map(l => <a key={l} href="#">{l}</a>)}
            </div>
          </div>
        </div>
        <div className="ft-bottom">
          <span>© 2026 Aurum Dubai Estates LLC · RERA License #12345</span>
          <span><a href="#">Privacy</a> · <a href="#">Terms</a> · <a href="#">Disclaimer</a></span>
        </div>
      </footer>

      {/* Floating CTA */}
      <div className="fcta" onClick={() => scrollTo('contact')}>
        <div className="fcta-dot">💬</div>
        <div className="fcta-txt">
          <div className="fcta-l">Free consultation</div>
          <div className="fcta-v">Talk to an Expert</div>
        </div>
      </div>
    </>
  )
}
